
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jennakinos',
  applicationName: 'recipeappserverless-app',
  appUid: 'dX2LqcsJ6DqY4gH0Kx',
  orgUid: 'H2XHp0YGYC1xRHLtSZ',
  deploymentUid: '48b1224e-d36e-47ee-99f7-40d0c1d1c336',
  serviceName: 'recipeappserverless',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'recipeappserverless-dev-deleteIngredient', timeout: 30 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.deleteIngredient, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}