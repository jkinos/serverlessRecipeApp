
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jennakinos',
  applicationName: 'recipeappserverless-app',
  appUid: 'dX2LqcsJ6DqY4gH0Kx',
  orgUid: 'H2XHp0YGYC1xRHLtSZ',
  deploymentUid: 'd38b10a4-e2fc-4d64-8d2d-9765232385be',
  serviceName: 'recipeappserverless',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'recipeappserverless-dev-getAllRecipes', timeout: 30 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getAllRecipes, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}