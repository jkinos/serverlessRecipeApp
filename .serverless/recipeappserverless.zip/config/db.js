module.exports =  {
    database: 'recipeAppDB',
    host: 'recipe-app-db.cc81rtksyagj.eu-west-1.rds.amazonaws.com',
    port: '5432',
    user: 'postgres',
    password: 'teamvegan',
}